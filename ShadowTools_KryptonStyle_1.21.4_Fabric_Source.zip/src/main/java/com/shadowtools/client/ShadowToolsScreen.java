package com.shadowtools.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class ShadowToolsScreen extends Screen {
    private Category category=Category.COMBAT;
    private Module selected;
    private int panelX,panelY;
    public ShadowToolsScreen(){super(Text.literal("SHADOWTOOLS"));}
    @Override protected void init() { rebuild(); }
    private void rebuild() {
        clearChildren();
        panelX=width/2-205; panelY=height/2-125;
        int x=panelX+12, y=panelY+34;
        int tabW=88;
        for(Category c:Category.values()) {
            final Category chosen=c;
            addDrawableChild(ButtonWidget.builder(Text.literal(c.name()),b->{category=chosen;selected=null;rebuild();})
                .dimensions(x,y,tabW,20).build());
            x+=tabW+4;
        }
        int rowY=panelY+65;
        for(Module m:ShadowToolsClient.MODULES.by(category)) {
            final Module target=m;
            addDrawableChild(ButtonWidget.builder(Text.literal((m.enabled?"§aON  ":"§7OFF ") + m.name),b->{
                target.toggle(); ConfigManager.save(ShadowToolsClient.MODULES); rebuild();
            }).dimensions(panelX+14,rowY,174,20).build());
            rowY+=23;
        }
        if(selected!=null) addSettingsButtons();
        addDrawableChild(ButtonWidget.builder(Text.literal("SAVE"),b->ConfigManager.save(ShadowToolsClient.MODULES))
            .dimensions(panelX+14,panelY+218,78,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("CLOSE"),b->close())
            .dimensions(panelX+300,panelY+218,92,20).build());
    }
    private void addSettingsButtons() {
        int x=panelX+208, y=panelY+72;
        Module m=selected;
        addDrawableChild(ButtonWidget.builder(Text.literal("Selected: "+m.name),b->{}).dimensions(x,y,176,20).build());
        y+=25;
        addDrawableChild(ButtonWidget.builder(Text.literal("Alpha: "+String.format("%.2f",m.alpha)),b->{
            m.alpha=m.alpha>=0.95f?0.20f:m.alpha+0.10f; ConfigManager.save(ShadowToolsClient.MODULES); rebuild();
        }).dimensions(x,y,176,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Min Y: "+m.minY),b->{
            m.minY=m.minY>=300?-64:m.minY+16; ConfigManager.save(ShadowToolsClient.MODULES); rebuild();
        }).dimensions(x,y,176,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Max Y: "+m.maxY),b->{
            m.maxY=m.maxY>=320?16:m.maxY+16; ConfigManager.save(ShadowToolsClient.MODULES); rebuild();
        }).dimensions(x,y,176,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Chest filter: "+m.chests),b->{
            m.chests=!m.chests; ConfigManager.save(ShadowToolsClient.MODULES); rebuild();
        }).dimensions(x,y,176,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Shulker filter: "+m.shulkers),b->{
            m.shulkers=!m.shulkers; ConfigManager.save(ShadowToolsClient.MODULES); rebuild();
        }).dimensions(x,y,176,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Spawner filter: "+m.spawners),b->{
            m.spawners=!m.spawners; ConfigManager.save(ShadowToolsClient.MODULES); rebuild();
        }).dimensions(x,y,176,20).build());
    }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button) {
        if(button==1 && mouseX>=panelX+14 && mouseX<=panelX+188) {
            int idx=(int)((mouseY-(panelY+65))/23);
            var list=ShadowToolsClient.MODULES.by(category);
            if(idx>=0 && idx<list.size()) { selected=list.get(idx); rebuild(); return true; }
        }
        return super.mouseClicked(mouseX,mouseY,button);
    }
    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta) {
        renderBackground(ctx,mouseX,mouseY,delta);
        ctx.fill(panelX,panelY,panelX+410,panelY+250,0xF010101A);
        ctx.fill(panelX,panelY,panelX+410,panelY+27,0xFF21132E);
        ctx.fill(panelX,panelY,panelX+3,panelY+250,0xFFFF62C4);
        ctx.drawText(textRenderer,"SHADOWTOOLS  /  KRYPTON THEME",panelX+12,panelY+9,0xFFFF9AD6,false);
        ctx.drawText(textRenderer,"L-click: toggle    R-click: module settings",panelX+14,panelY+53,0xFFBDB4C8,false);
        if(selected!=null) {
            ctx.drawText(textRenderer,selected.description,panelX+208,panelY+57,0xFFBDB4C8,false);
        } else {
            ctx.drawText(textRenderer,"Select a module with right-click to edit its profile.",panelX+208,panelY+75,0xFFBDB4C8,false);
        }
        super.render(ctx,mouseX,mouseY,delta);
    }
    @Override public boolean keyPressed(int keyCode,int scanCode,int modifiers) {
        if(keyCode==GLFW.GLFW_KEY_ESCAPE){close();return true;}
        return super.keyPressed(keyCode,scanCode,modifiers);
    }
    @Override public boolean shouldPause(){return false;}
}
