package com.shadowtools.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public final class ShadowToolsClient implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static KeyBinding openMenu;
    private static final Map<Module,KeyBinding> binds = new LinkedHashMap<>();

    @Override public void onInitializeClient() {
        ConfigManager.load(MODULES);
        openMenu=KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.shadowtools.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.shadowtools"
        ));
        for(Module m:MODULES.all()) {
            if(m.keyCode!=0) binds.put(m, KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.shadowtools."+m.name.toLowerCase(), InputUtil.Type.KEYSYM, m.keyCode, "category.shadowtools"
            )));
        }
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while(openMenu.wasPressed()) client.setScreen(new ShadowToolsScreen());
            for(var entry:binds.entrySet()) while(entry.getValue().wasPressed()) {
                entry.getKey().toggle(); ConfigManager.save(MODULES);
            }
        });
        HudRenderCallback.EVENT.register((draw, tickCounter) -> {
            if(clientNull()) return;
            int y=8;
            draw.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                "SHADOWTOOLS",8,y,0xFFFF75C8,true);
            y+=12;
            for(Module m:MODULES.all()) if(m.enabled) {
                draw.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                    m.name,8,y,0xFFE7D9FF,true); y+=10;
            }
        });
    }
    private boolean clientNull(){return net.minecraft.client.MinecraftClient.getInstance().player==null;}
}
