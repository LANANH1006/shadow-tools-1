package com.shadowtools.client;

import java.util.*;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    public ModuleManager() {
        add("SafeAnchor", "Anchor helper profile and status HUD (manual placement).", Category.COMBAT);
        add("CrystalMacro", "Crystal workflow profile; no unattended rapid-fire.", Category.COMBAT);
        add("CombatHUD", "Show selected combat status on screen.", Category.COMBAT);
        add("StorageESP", "Storage highlight profile for client-visible world data.", Category.RENDER);
        add("BlockESP", "Selected block highlight profile.", Category.RENDER);
        add("SpawnerESP", "Spawner highlight profile.", Category.RENDER);
        add("HoleESP", "Safe-hole inspection profile.", Category.RENDER);
        add("LightFinder", "Light-source inspection profile.", Category.RENDER);
        add("SuspiciousESP", "Review suspicious block patterns in visible chunks.", Category.WORLD);
        add("ChunkFinder", "Inspect client-known chunks only.", Category.WORLD);
        add("BaseRender", "Base-related visual organization tools.", Category.WORLD);
        add("ClickGUI", "Krypton-inspired module interface.", Category.MISC);
    }
    private void add(String n,String d,Category c) { modules.add(new Module(n,d,c,0)); }
    public List<Module> all() { return Collections.unmodifiableList(modules); }
    public List<Module> by(Category c) { return modules.stream().filter(m -> m.category==c).toList(); }
    public Module get(String n) { return modules.stream().filter(m -> m.name.equalsIgnoreCase(n)).findFirst().orElse(null); }
}
