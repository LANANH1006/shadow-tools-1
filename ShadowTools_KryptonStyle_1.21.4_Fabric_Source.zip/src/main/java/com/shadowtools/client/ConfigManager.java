package com.shadowtools.client;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public final class ConfigManager {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("shadowtools.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private ConfigManager() {}
    public static void save(ModuleManager manager) {
        try {
            JsonObject root = new JsonObject();
            for (Module m : manager.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled",m.enabled); o.addProperty("keyCode",m.keyCode);
                o.addProperty("alpha",m.alpha); o.addProperty("minY",m.minY); o.addProperty("maxY",m.maxY);
                o.addProperty("chests",m.chests); o.addProperty("shulkers",m.shulkers);
                o.addProperty("spawners",m.spawners); o.addProperty("barrels",m.barrels);
                root.add(m.name,o);
            }
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE,GSON.toJson(root));
        } catch (Exception e) { System.err.println("[ShadowTools] Config save failed: "+e.getMessage()); }
    }
    public static void load(ModuleManager manager) {
        if (!Files.exists(FILE)) return;
        try {
            JsonObject root=JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Module m:manager.all()) if(root.has(m.name)) {
                JsonObject o=root.getAsJsonObject(m.name);
                m.enabled=getBool(o,"enabled",false); m.keyCode=getInt(o,"keyCode",0);
                m.alpha=getFloat(o,"alpha",0.72f); m.minY=getInt(o,"minY",-64); m.maxY=getInt(o,"maxY",320);
                m.chests=getBool(o,"chests",true); m.shulkers=getBool(o,"shulkers",true);
                m.spawners=getBool(o,"spawners",true); m.barrels=getBool(o,"barrels",true);
            }
        } catch (Exception e) { System.err.println("[ShadowTools] Config load failed: "+e.getMessage()); }
    }
    private static boolean getBool(JsonObject o,String k,boolean d){return o.has(k)?o.get(k).getAsBoolean():d;}
    private static int getInt(JsonObject o,String k,int d){return o.has(k)?o.get(k).getAsInt():d;}
    private static float getFloat(JsonObject o,String k,float d){return o.has(k)?o.get(k).getAsFloat():d;}
}
